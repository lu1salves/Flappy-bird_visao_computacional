import React from 'react'
import Flappy_Bird_icon from './images/Flappy_Bird_icon.png'
import pose_detect from './images/pose-detect.png'
import './Instruction.css';

const Instruction = ({ setPrePare }) => {
    return (
        <div className="background">
            <h1 className="title"> Play Flappy Bird Game with Pose Detection ! </h1>
            <div className="container">
                <ul className="instruction-container">
                    <li className="instruction">
                        texto:<br />

                    </li>
                    <li className="instruction">
                        texto:<br />
                        texto texto
                    </li>
                    <li className="instruction">
                        texto: <br />
                        texto
                    </li>
                    <li className="instruction">
                        texto
                    </li>
                </ul>
                <div className="image-container">
                    <img className="image" src={Flappy_Bird_icon} />
                    <img className="image" src={pose_detect} />
                </div>
            </div>
            <div className="btn-container">
                <button className="btn">Back</button>
                <button className="btn" onClick={() => { setPrePare(true) }}>Let's Start! </button>
            </div>
        </div>
    )
}

export default Instruction
